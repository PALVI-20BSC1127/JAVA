package com.rahul.service;

public interface TransService {

	public String getUserId(String transId);
}
